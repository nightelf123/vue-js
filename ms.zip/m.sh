#!/bin/bash

# 检查命令行参数
if [ $# -ne 1 ]; then
    echo "Usage: $0 <port>"
    exit 1
fi

# 确保 masscan 已安装
command -v masscan >/dev/null 2>&1 || { echo >&2 "masscan is required but not installed. Aborting."; exit 1; }

# 获取端口号
port="$1"

# 确保 IP 地址段文件存在
ip_ranges_file="ip.txt"
if [ ! -f "$ip_ranges_file" ]; then
    echo "File $ip_ranges_file not found."
    exit 1
fi

# 扫描每个 IP 地址段，并将结果格式化并输出到文件
echo "Scanning IP ranges from $ip_ranges_file on port $port ..."

# 逐行扫描
while IFS= read -r ip_range; do
    echo "Scanning IP range: $ip_range"
    masscan -p "$port" "$ip_range" -oG - | awk '/open/ { print "open", $5, $4, $3, $2 }' | sed 's/\// /g' | tee -a shuchu.txt
done < "$ip_ranges_file"

echo "Scan completed. Results saved to shuchu.txt."
